Minetest Game mod: screwdriver
==============================
See license.txt for license information.

License of source code
----------------------
Originally by RealBadAngel, Maciej Kasatkin (LGPLv2.1+)
Various Minetest developers and contributors (LGPLv2.1+)

License of media (textures)
---------------------------
Created by Gambit (CC BY-SA 3.0):
  screwdriver.png
