Minetest Mod - Turret Gun [shooter_turret]
==========================================

Depends: shooter_rocket

Adds a mountable turret gun which can also be triggered by mesecon signals.
Still WIP and experimental and may be subject to change or removal.

Crafting
========

S = Steel Ingot  [default:steel_ingot]
B = Bronze Ingot [default:bronze_ingot]
D = Diamond      [default:diamond]

Turret Gun: [shooter_turret:turret]

+---+---+---+
| B | B | S |
+---+---+---+
|   | B | S |
+---+---+---+
|   | D |   |
+---+---+---+

