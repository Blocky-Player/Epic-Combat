Minetest Mod - Rocket Launcher [shooter_rocket]
===============================================

Depends: shooter

Adds rocket missiles and launching gun.

Crafting
========

S = Steel Ingot  [default:steel_ingot]
B = Bronze Ingot [default:bronze_ingot]
D = Diamond      [default:diamond]
G = Gunpowder    [shooter:gunpowder]

Rocket: [shooter_rocket:rocket]

+---+---+---+
| B | G | B |
+---+---+---+

Rocket Gun: [shooter_rocket:rocket_gun]

+---+---+---+
| B | S | S |
+---+---+---+
|   |   | D |
+---+---+---+

