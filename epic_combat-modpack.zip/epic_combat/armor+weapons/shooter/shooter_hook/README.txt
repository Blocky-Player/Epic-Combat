Minetest Mod - Grapple Hook [shooter_hook]
==========================================

Depends: shooter

Adds a teleporting grapple hook which can be thrown or launched
further from a grapple hook gun.

Crafting
========

S = Steel Ingot  [default:steel_ingot]
D = Diamond      [default:diamond]

Grappling Hook: [shooter_hook:grapple_hook]

+---+---+---+
| S | S | D |
+---+---+---+
| S | S |   |
+---+---+---+
| D |   | S |
+---+---+---+

Grappling Hook Gun: [shooter_hook:grapple_gun]

+---+---+
| S | S |
+---+---+
|   | D |
+---+---+

