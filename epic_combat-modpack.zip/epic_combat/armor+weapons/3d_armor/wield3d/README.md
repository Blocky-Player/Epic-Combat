[mod] 3d wielded items [wield3d]
================================

Mod Version: 0.4.0

Minetest Version: 0.4.12 or later

Decription: Visible 3d wielded items for Minetest

Depends: default

Makes hand wielded items visible to other players.

By default the wielded object is updated at one second intervals,
you can override this by adding wield3d_update_time = 1 (seconds)
to your minetest.conf

