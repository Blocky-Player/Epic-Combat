-- ctf_ranged/wep_defns.lua


--[[
   Tier 1:
   - pistol: ctf_ranged:makarov
   - DMR: ctf_ranged:mini14
   - Shotgun: ctf_ranged:remington870
   - SMG: ctf_ranged:thompson
   - Rifle: ctf_ranged:ak47
   - HMG: ctf_ranged:rpk
   Tier 2:
   - pistol: ctf_ranged:glock17
   - DMR: ctf_ranged:svd
   - Shotgun: ctf_ranged:benelli
   - SMG: ctf_ranged:uzi
   - Rifle: ctf_ranged:m16
   - HMG: ctf_ranged:m60
   Tier 3:
   - pistol: ctf_ranged:deagle
   - DMR: ctf_ranged:m200
   - Shotgun: ctf_ranged:jackhammer
   - SMG: ctf_ranged:mp5
   - Rifle: ctf_ranged:scar
   - HMG: ctf_ranged:minigun
   Energy weapons:
   - E: ctf_ranged:energy_pistol
   - E: ctf_ranged:energy_rifle
   - E: ctf_ranged:energy_shotgun

]]--


--------------------------
-- Tier 1
--------------------------

ctf_ranged.simple_register_gun("ctf_ranged:smg", {
	type = "smg",
	description = "Submachinegun",
	texture = "ctf_ranged_smgun.png",
	fire_sound = "ctf_ranged_pistol",
	bullet = {
		spread = 1,
	},
	automatic = true,
	rounds = 36,
	range = 75,
	damage = 1,
	fire_interval = 0.1,
	liquid_travel_dist = 2,
})
