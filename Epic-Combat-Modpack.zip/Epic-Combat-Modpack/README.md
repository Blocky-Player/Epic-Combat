# Epic-Combat
Epic Combat, made for Minetest. Contains a modpack version, to work alongside existing games.
Epic Combat is an action-focused game and has many mobs and weapons. Find ores to upgrade your tools and rid the land of terrible monsters whilst also fighting other 
players to the death. Choose from many different weapons, each with their own advantages and disadvantages, and forged from different materials and metals.

Make sure you don't take these fights seriously and be a good sport when playing with other players.
