
armor:register_armor("wool_armor:boots_wool", {
	description = "Wool Boots",
	inventory_image = "white_wool_armor",
	groups = {armor_feet=1, armor_heal=2, armor_use=500, physics_jump=0.25, physics_speed=1, armor_fire=-1},
	armor_groups = {fleshy=5},
	damage_groups = {cracky=2, fleshy=-0.5, snappy=1, level=3},
})


armor:register_armor("wool_armor:tshirt_wool", {
	description = "Wool T-shirt",
	inventory_image = "white_wool_armor",
	groups = {armor_torso=1, armor_heal=2, armor_use=500, armor_fire=-1},
	armor_groups = {fleshy=5},
	damage_groups = {cracky=2, fleshy=-0.5, snappy=1, level=3},
})


armor:register_armor("wool_armor:cap_wool", {
	description = "Wool Cap",
	inventory_image = "white_wool_armor",
	groups = {armor_head=1, armor_heal=2, armor_use=500, armor_fire=-1},
	armor_groups = {fleshy=5},
	damage_groups = {cracky=2, fleshy=-0.5, snappy=1, level=3},
})


armor:register_armor("wool_armor:leggings_wool", {
	description = "Wool Leggings",
	inventory_image = "white_wool_armor.png",
	groups = {armor_legs=1, armor_heal=2, armor_use=500, armor_fire=-1},
	armor_groups = {fleshy=5},
	damage_groups = {cracky=2, fleshy=-0.5, snappy=1, level=3},
})

minetest.register_craft({
	output = "wool_armor:cap_wool",
	recipe = {
		{"group:wool", "group:wool", "group:wool"},
		{"group:wool", "", "group:wool"},
		{"", "", ""},
	},
})
minetest.register_craft({
	output = "wool_armor:tshirt_wool",
	recipe = {
		{"group:wool", "", "group:wool"},
		{"group:wool", "group:wool", "group:wool"},
		{"group:wool", "group:wool", "group:wool"},
	},
})
minetest.register_craft({
	output = "wool_armor:leggings_wool",
	recipe = {
		{"group:wool", "group:wool", "group:wool"},
		{"group:wool", "", "group:wool"},
		{"group:wool", "", "group:wool"},
	},
})
minetest.register_craft({
	output = "wool_armor:boots_wool",
	recipe = {
		{"group:wool", "", "group:wool"},
		{"group:wool", "", "group:wool"},
	},
})



