minetest.register_privilege("ctf_admin", {
	description = "Manage administrative ctf settings/commands.",
	give_to_singleplayer = false,
	give_to_admin = false,
})
