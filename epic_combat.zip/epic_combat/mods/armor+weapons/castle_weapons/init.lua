local MP = minetest.get_modpath(minetest.get_current_modname())

dofile(MP.."/crossbow.lua")



