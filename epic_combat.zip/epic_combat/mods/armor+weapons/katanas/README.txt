License of source code
----------------------

Copyright (c) 2021 blocky_player.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

For more details:
https://opensource.org/licenses/MIT
CC-BY-SA 3.0

Textures
--------
Blocky Player: katans_tool_bronze.png
Blocky Player: katans_tool_mese.png
Blocky Player: katans_tool_steel.png
Blocky Player: katans_tool_diamond.png

Code
----
Bloky Player: init.lua
              