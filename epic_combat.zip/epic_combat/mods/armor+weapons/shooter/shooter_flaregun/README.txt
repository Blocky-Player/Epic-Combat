Minetest Mod - Flare Gun [shooter_flaregun]
===========================================

Depends: shooter

Adds a flare-gun with temporary light emitting flares.

Crafting
========

S = Steel Ingot  [default:steel_ingot]
C = Copper Ingot [default:copper_ingot]
P = Paper        [default:paper]
G = Gunpowder    [shooter:gunpowder]

Flare: [shooter_flaregun:flare]

+---+---+
| G | P |
+---+---+

Flare Gun: [shooter_flaregun:flaregun]

+---+---+---+
| C | C | C |
+---+---+---+
|   |   | S |
+---+---+---+

