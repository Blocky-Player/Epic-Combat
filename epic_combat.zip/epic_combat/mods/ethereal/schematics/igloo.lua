
local _ = {name = "air", prob = 0}
local S = {name = "default:snowblock", prob = 255}
local P = {name = "default:pine_bush_stem", prob = 50}
local C = {name = "ethereal:coconut", prob = 50}

ethereal.igloo = {

	size = {x = 7, y = 5, z = 8},

	data = {

	_,_,S,S,S,_,_,
	_,_,S,_,S,_,_,
	_,_,S,_,S,_,_,
	_,_,_,S,_,_,_,
	_,_,_,_,_,_,_,

	_,_,S,S,S,_,_,
	_,_,S,_,S,_,_,
	_,_,S,_,S,_,_,
	_,_,_,S,_,_,_,
	_,_,_,_,_,_,_,

	_,S,S,S,S,S,_,
	_,S,_,_,_,S,_,
	_,S,_,_,_,S,_,
	_,_,S,S,S,_,_,
	_,_,_,_,_,_,_,

	S,S,S,S,S,S,S,
	S,P,_,_,_,C,S,
	S,_,_,_,_,_,S,
	_,S,_,_,_,S,_,
	_,_,S,S,S,_,_,

	S,S,S,S,S,S,S,
	S,_,_,_,_,_,S,
	S,_,_,_,_,_,S,
	_,S,_,_,_,S,_,
	_,_,S,S,S,_,_,

	S,S,S,S,S,S,S,
	S,_,_,_,_,_,S,
	S,_,_,_,_,_,S,
	_,S,_,_,_,S,_,
	_,_,S,S,S,_,_,

	_,S,S,S,S,S,_,
	_,S,_,_,_,S,_,
	_,S,_,_,_,S,_,
	_,_,S,S,S,_,_,
	_,_,_,_,_,_,_,

	_,_,S,S,S,_,_,
	_,_,S,S,S,_,_,
	_,_,S,S,S,_,_,
	_,_,_,_,_,_,_,
	_,_,_,_,_,_,_,

	}
}
