chatcmdbuilder = dofile(minetest.get_modpath(minetest.get_current_modname()).."/chatcmdbuilder.lua")

-- Compat
ChatCmdBuilder = chatcmdbuilder
