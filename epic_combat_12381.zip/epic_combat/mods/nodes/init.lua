minetest.register_node("nodes:reinforced_cobble", {
    description = "Reinforced Cobblestone",
    tiles = {"reinforced_cobble.png"},
    is_ground_content = false,
    groups = {cracky = 1, stone = 2},
})
