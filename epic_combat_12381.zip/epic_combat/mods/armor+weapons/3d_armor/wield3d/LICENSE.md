[mod] 3d wielded items [wield3d]
================================

Copyright (C) 2013 Stuart Jones - WTFPL
